<?php
/**
 * Ruang Curhat Anonim — API Configuration
 * Database connection, helpers, and shared configuration.
 */

// --- Database Connection ---
define('DB_HOST', 'localhost');
define('DB_NAME', 'ruang_curhat');
define('DB_USER', 'root');
define('DB_PASS', '');

function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO(
            "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4",
            DB_USER, DB_PASS,
            [
                PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES => false
            ]
        );
    }
    return $pdo;
}

// --- Session for anonymous tracking ---
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function getSessionId(): string {
    return session_id();
}

// --- CORS & Headers ---
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

// --- Helper: JSON Response ---
function jsonResponse($data, int $status = 200): void {
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

function jsonError(string $message, int $status = 400): void {
    jsonResponse(['error' => $message], $status);
}

// --- Helper: Sanitize ---
function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

// --- Helper: Get POST JSON body ---
function getJsonBody(): array {
    $raw = file_get_contents('php://input');
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// --- Content Moderation ---
function moderateContent(string $text): array {
    $blocked = ['bunuh', 'mati', 'benci sekali', 'sampah', 'goblok', 'anjing', 'babi', 'setan', 'iblis'];
    $lower = mb_strtolower($text, 'UTF-8');
    foreach ($blocked as $word) {
        if (mb_strpos($lower, $word) !== false) {
            return ['safe' => false, 'reason' => 'Konten mengandung kata yang tidak pantas.'];
        }
    }
    return ['safe' => true];
}

// --- Anonymous Identity ---
function getRandomIdentity(): array {
    $names = ['Anonim Beruang','Anonim Kucing','Anonim Kelinci','Anonim Burung','Anonim Panda','Anonim Rusa','Anonim Lumba-lumba','Anonim Penguin','Anonim Koala','Anonim Rubah','Anonim Kuda','Anonim Harimau','Anonim Gajah','Anonim Singa','Anonim Elang','Anonim Ikan Hiu'];
    $avatars = ['🐻','🐱','🐰','🐦','🐼','🦌','🐬','🐧','🐨','🦊','🐴','🐯','🐘','🦁','🦅','🦈'];
    $i = array_rand($names);
    return ['name' => $names[$i], 'avatar' => $avatars[$i]];
}

// --- AI Supportive Responses ---
function getAIResponse(string $mood): string {
    $responses = [
        'sad' => [
            "Aku mengerti perasaanmu, dan itu wajar. Kamu tidak sendirian dalam ini. Ingat, setiap badai pasti berlalu, dan matahari akan bersinar kembali. 💙",
            "Menangis itu tidak apa-apa. Itu tandanya kamu manusia yang punya perasaan. Tapi percayalah, hari-hari yang lebih baik sedang menunggumu. 🌈",
            "Perasaan sedih itu sementara, tapi kekuatanmu untuk melewatinya itu permanen. Kamu lebih kuat dari yang kamu kira. 💪"
        ],
        'confused' => [
            "Bingung itu wajar — itu tanda kamu sedang bertumbuh. Tidak semua pertanyaan butuh jawaban hari ini. Ambil waktu untuk dirimu. 🌱",
            "Hidup memang penuh pilihan yang membingungkan. Tapi ingat, tidak ada keputusan yang salah jika kamu sudah berusaha yang terbaik. 🧭"
        ],
        'happy' => [
            "Senang mendengar kamu bahagia! Simpan momen ini di hatimu, dan bagikan kebahagiaan ini kepada orang-orang di sekitarmu. ☀️",
            "Kebahagiaan itu menular. Terima kasih sudah berbagi cerita indahmu — kamu bisa menjadi inspirasi bagi orang lain! 🎉"
        ],
        'angry' => [
            "Marah itu wajar, dan perasaanmu valid. Tapi ingat, kemarahan yang dikelola dengan baik bisa menjadi kekuatan untuk perubahan positif. 🔥",
            "Aku mendengarmu. Kadang dunia memang tidak adil, tapi kamu punya kekuatan untuk merespons dengan bijak. Tarik nafas dalam-dalam. 🌬️"
        ],
        'stressed' => [
            "Stres itu berat, tapi kamu tidak harus menanggungnya sendiri. Jangan ragu untuk meminta bantuan — itu bukan tanda kelemahan. 🤗",
            "Ambil satu langkah kecil dalam satu waktu. Kamu tidak harus menyelesaikan semuanya sekaligus. Bernafas, istirahat, lalu lanjutkan. 🍃"
        ]
    ];
    $pool = $responses[$mood] ?? $responses['sad'];
    return $pool[array_rand($pool)];
}

// --- Rate Limit (simple per-session) ---
function rateLimitCheck(string $action, int $maxPerMinute = 10): bool {
    $key = 'rate_' . $action;
    if (!isset($_SESSION[$key])) {
        $_SESSION[$key] = [];
    }
    $now = time();
    $_SESSION[$key] = array_filter($_SESSION[$key], fn($t) => $now - $t < 60);
    if (count($_SESSION[$key]) >= $maxPerMinute) {
        return false;
    }
    $_SESSION[$key][] = $now;
    return true;
}

// --- Time Ago helper ---
function timeAgo(string $datetime): string {
    $ts = strtotime($datetime);
    $diff = time() - $ts;
    if ($diff < 60) return 'Baru saja';
    if ($diff < 3600) return floor($diff / 60) . ' menit lalu';
    if ($diff < 86400) return floor($diff / 3600) . ' jam lalu';
    if ($diff < 604800) return floor($diff / 86400) . ' hari lalu';
    return floor($diff / 604800) . ' minggu lalu';
}
?>
