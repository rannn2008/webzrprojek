/* ============================================
   RUANG CURHAT ANONIM — Application Logic
   Uses PHP/MySQL backend via fetch() API
   ============================================ */

const API_BASE = 'api';

// ---- Constants ----
const CATEGORIES = [
  { id: 'all', label: 'Semua', emoji: '✨' },
  { id: 'school', label: 'Sekolah & Pendidikan', emoji: '📚' },
  { id: 'friendship', label: 'Persahabatan', emoji: '🤝' },
  { id: 'family', label: 'Keluarga', emoji: '👨‍👩‍👧‍👦' },
  { id: 'life', label: 'Masalah Hidup', emoji: '🌊' },
  { id: 'motivation', label: 'Motivasi', emoji: '🔥' },
  { id: 'funny', label: 'Cerita Lucu', emoji: '😂' }
];

const MOODS = [
  { id: 'sad', label: 'Sedih', emoji: '😢' },
  { id: 'confused', label: 'Bingung', emoji: '😕' },
  { id: 'happy', label: 'Senang', emoji: '😊' },
  { id: 'angry', label: 'Marah', emoji: '😠' },
  { id: 'stressed', label: 'Stres', emoji: '😰' }
];

// ---- API Helpers ----
async function apiGet(endpoint) {
  const res = await fetch(`${API_BASE}/${endpoint}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Gagal memuat data.');
  }
  return res.json();
}

async function apiPost(endpoint, data) {
  const res = await fetch(`${API_BASE}/${endpoint}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  const json = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(json.error || 'Terjadi kesalahan.');
  }
  return json;
}

// ---- Utility ----
function truncateText(text, maxLength) {
  if (text.length <= maxLength) return text;
  return text.substr(0, maxLength).trim() + '...';
}

function getMoodInfo(moodId) {
  return MOODS.find(m => m.id === moodId) || MOODS[0];
}

function getCategoryInfo(catId) {
  return CATEGORIES.find(c => c.id === catId) || CATEGORIES[0];
}

function formatNumber(num) {
  num = parseInt(num) || 0;
  if (num >= 1000) return (num / 1000).toFixed(1) + 'rb';
  return num.toString();
}

// ---- Rendering ----
function renderStoryCard(s) {
  const mood = getMoodInfo(s.mood);
  const cat = getCategoryInfo(s.category);
  const relate = parseInt(s.relate_count) || 0;
  const support = parseInt(s.support_count) || 0;
  const helpful = parseInt(s.helpful_count) || 0;
  const commentCount = parseInt(s.comment_count) || 0;

  return `
    <article class="story-card" onclick="navigateToStory(${s.id})">
      <div class="story-card-header">
        <div class="story-meta">
          <div class="avatar-anon">${s.anon_avatar}</div>
          <div>
            <div class="story-author">${s.anon_name}</div>
            <div class="story-time">${s.time_ago}</div>
          </div>
        </div>
        <span class="mood-badge mood-${s.mood}">${mood.emoji} ${mood.label}</span>
      </div>
      <span class="story-category cat-${s.category}">${cat.emoji} ${cat.label}</span>
      <h3 class="story-title">${truncateText(s.title, 80)}</h3>
      <p class="story-excerpt">${truncateText(s.content, 150)}</p>
      <div class="story-footer">
        <div class="reactions-mini">
          <span class="reaction-mini">🤝 ${formatNumber(relate)}</span>
          <span class="reaction-mini">💕 ${formatNumber(support)}</span>
          <span class="reaction-mini">💡 ${formatNumber(helpful)}</span>
        </div>
        <span class="comment-count">💬 ${commentCount}</span>
      </div>
    </article>
  `;
}

function renderTrendingItem(s, rank) {
  const relate = parseInt(s.relate_count) || 0;
  const support = parseInt(s.support_count) || 0;
  const commentCount = parseInt(s.comment_count) || 0;
  return `
    <a href="story.html?id=${s.id}" class="trending-item">
      <span class="trending-rank">${String(rank).padStart(2, '0')}</span>
      <div class="trending-content">
        <h4>${truncateText(s.title, 60)}</h4>
        <div class="trending-stats">
          <span>🤝 ${formatNumber(relate)}</span>
          <span>💕 ${formatNumber(support)}</span>
          <span>💬 ${commentCount} komentar</span>
        </div>
      </div>
    </a>
  `;
}

// ---- Page: Homepage ----
async function initHomepage() {
  let activeCategory = 'all';

  // Category pills
  const catBar = document.getElementById('categoryBar');
  if (catBar) {
    catBar.innerHTML = CATEGORIES.map(c =>
      `<button class="cat-pill ${c.id === 'all' ? 'active' : ''}" data-cat="${c.id}">
        <span class="emoji">${c.emoji}</span> ${c.label}
      </button>`
    ).join('');

    catBar.addEventListener('click', (e) => {
      const pill = e.target.closest('.cat-pill');
      if (!pill) return;
      activeCategory = pill.dataset.cat;
      catBar.querySelectorAll('.cat-pill').forEach(p => p.classList.remove('active'));
      pill.classList.add('active');
      renderFeed();
    });
  }

  // Load trending
  const trendingList = document.getElementById('trendingList');
  if (trendingList) {
    try {
      const data = await apiGet('stories.php?sort=trending&limit=5');
      trendingList.innerHTML = data.stories.map((s, i) => renderTrendingItem(s, i + 1)).join('');
    } catch (e) {
      trendingList.innerHTML = '<p style="padding:1rem;color:var(--text-muted);">Gagal memuat trending.</p>';
    }
  }

  // Load stats
  try {
    const stats = await apiGet('stats.php');
    const statEls = document.querySelectorAll('.stat-number');
    if (statEls.length >= 3) {
      animateCounter(statEls[0], stats.stories);
      animateCounter(statEls[1], stats.reactions);
      animateCounter(statEls[2], stats.comments);
    }
  } catch (e) { /* ignore */ }

  // Feed
  async function renderFeed() {
    const grid = document.getElementById('storiesGrid');
    if (!grid) return;

    grid.innerHTML = '<div style="grid-column:1/-1;text-align:center;padding:2rem;"><div class="skeleton skeleton-title" style="margin:0 auto;"></div></div>';

    try {
      const catParam = activeCategory !== 'all' ? `&category=${activeCategory}` : '';
      const data = await apiGet(`stories.php?sort=recent&limit=12${catParam}`);

      if (data.stories.length === 0) {
        grid.innerHTML = `
          <div class="empty-state" style="grid-column:1/-1;">
            <div class="icon">📭</div>
            <h3>Belum ada cerita di kategori ini</h3>
            <p>Jadilah yang pertama berbagi cerita!</p>
            <a href="post.html" class="btn btn-primary">✍️ Tulis Cerita</a>
          </div>`;
      } else {
        grid.innerHTML = data.stories.map(s => renderStoryCard(s)).join('');
      }
    } catch (e) {
      grid.innerHTML = '<div class="empty-state" style="grid-column:1/-1;"><p>Gagal memuat cerita. Pastikan database sudah di-setup.</p></div>';
    }
  }
  renderFeed();

  // Random story FAB
  const fabRandom = document.getElementById('fabRandom');
  if (fabRandom) {
    fabRandom.addEventListener('click', async () => {
      try {
        const data = await apiGet('random.php');
        window.location.href = `story.html?id=${data.id}`;
      } catch (e) {
        showToast('⚠️ Gagal memuat cerita random.');
      }
    });
  }
}

// ---- Page: Post Story ----
function initPostPage() {
  const form = document.getElementById('postForm');
  const successEl = document.getElementById('postSuccess');
  const formCard = document.getElementById('postFormCard');
  if (!form) return;

  let selectedMood = null;

  // Mood selector
  const moodSelector = document.getElementById('moodSelector');
  if (moodSelector) {
    moodSelector.innerHTML = MOODS.map(m =>
      `<button type="button" class="mood-option" data-mood="${m.id}">
        <span class="mood-emoji">${m.emoji}</span> ${m.label}
      </button>`
    ).join('');

    moodSelector.addEventListener('click', (e) => {
      const opt = e.target.closest('.mood-option');
      if (!opt) return;
      selectedMood = opt.dataset.mood;
      moodSelector.querySelectorAll('.mood-option').forEach(o => o.classList.remove('selected'));
      opt.classList.add('selected');
    });
  }

  // Category select
  const catSelect = document.getElementById('categorySelect');
  if (catSelect) {
    catSelect.innerHTML = '<option value="">— Pilih Kategori —</option>' +
      CATEGORIES.filter(c => c.id !== 'all').map(c =>
        `<option value="${c.id}">${c.emoji} ${c.label}</option>`
      ).join('');
  }

  // Char count
  const contentArea = document.getElementById('storyContent');
  const charCount = document.getElementById('charCount');
  const MAX_CHARS = 5000;
  if (contentArea && charCount) {
    contentArea.addEventListener('input', () => {
      const len = contentArea.value.length;
      charCount.textContent = `${len} / ${MAX_CHARS}`;
      charCount.className = 'char-count';
      if (len > MAX_CHARS * 0.9) charCount.classList.add('danger');
      else if (len > MAX_CHARS * 0.75) charCount.classList.add('warning');
    });
  }

  // Submit
  form.addEventListener('submit', async (e) => {
    e.preventDefault();

    const title = document.getElementById('storyTitle').value.trim();
    const content = contentArea.value.trim();
    const category = catSelect.value;

    if (!title || !content || !category) {
      showToast('⚠️ Mohon lengkapi semua field yang wajib diisi.');
      return;
    }
    if (!selectedMood) {
      showToast('⚠️ Pilih mood kamu dulu ya!');
      return;
    }
    if (content.length > MAX_CHARS) {
      showToast('⚠️ Cerita terlalu panjang.');
      return;
    }

    const submitBtn = form.querySelector('button[type="submit"]');
    submitBtn.disabled = true;
    submitBtn.textContent = '⏳ Mengirim...';

    try {
      const result = await apiPost('stories.php', { title, content, category, mood: selectedMood });

      if (formCard) formCard.style.display = 'none';
      if (successEl) {
        successEl.classList.add('show');
        const link = successEl.querySelector('.new-story-link');
        if (link) link.setAttribute('href', `story.html?id=${result.id}`);
      }
      showToast('🎉 Ceritamu berhasil dipublikasikan!');
    } catch (err) {
      showToast('❌ ' + err.message);
      submitBtn.disabled = false;
      submitBtn.textContent = '🚀 Publikasikan Cerita';
    }
  });
}

// ---- Page: Story Detail ----
async function initStoryDetail() {
  const params = new URLSearchParams(window.location.search);
  const storyId = params.get('id');
  if (!storyId) { window.location.href = 'index.html'; return; }

  const detailEl = document.getElementById('storyDetail');
  if (!detailEl) return;

  try {
    const data = await apiGet(`story.php?id=${storyId}`);
    const story = data.story;
    const mood = getMoodInfo(story.mood);
    const cat = getCategoryInfo(story.category);

    document.title = `${story.title} — Ruang Curhat Anonim`;

    const contentParagraphs = story.content.split('\n').filter(p => p.trim()).map(p => `<p>${p}</p>`).join('');

    detailEl.innerHTML = `
      <div class="story-detail-header">
        <div class="story-detail-meta">
          <div class="avatar-anon-lg">${story.anon_avatar}</div>
          <div class="story-detail-info">
            <div class="story-author">${story.anon_name}</div>
            <div class="story-time">${story.time_ago} · 👁️ ${formatNumber(story.views)} views</div>
          </div>
        </div>
        <div class="story-badges">
          <span class="mood-badge mood-${story.mood}">${mood.emoji} ${mood.label}</span>
          <span class="story-category cat-${story.category}">${cat.emoji} ${cat.label}</span>
        </div>
      </div>
      <h1 class="story-detail-title">${story.title}</h1>
      <div class="story-detail-content">${contentParagraphs}</div>
      <div class="reactions-bar" id="reactionsBar">
        <button class="reaction-btn ${story.user_reactions.includes('relate') ? 'active' : ''}" data-type="relate">
          🤝 Relate <span class="count">${story.reactions.relate}</span>
        </button>
        <button class="reaction-btn ${story.user_reactions.includes('support') ? 'active' : ''}" data-type="support">
          💕 Support <span class="count">${story.reactions.support}</span>
        </button>
        <button class="reaction-btn ${story.user_reactions.includes('helpful') ? 'active' : ''}" data-type="helpful">
          💡 Helpful Advice <span class="count">${story.reactions.helpful}</span>
        </button>
      </div>
    `;

    // AI response
    const aiEl = document.getElementById('aiResponse');
    if (aiEl) {
      aiEl.querySelector('.ai-text').textContent = story.ai_response;
    }

    // Reactions click handler
    const reactionsBar = document.getElementById('reactionsBar');
    reactionsBar?.addEventListener('click', async (e) => {
      const btn = e.target.closest('.reaction-btn');
      if (!btn) return;
      const type = btn.dataset.type;

      try {
        const result = await apiPost('reactions.php', { story_id: parseInt(storyId), type });
        btn.classList.toggle('active', result.action === 'added');
        // Update all counts
        reactionsBar.querySelectorAll('.reaction-btn').forEach(b => {
          const t = b.dataset.type;
          b.querySelector('.count').textContent = result.reactions[t];
        });
      } catch (err) {
        showToast('⚠️ ' + err.message);
      }
    });

    // Load comments
    await loadComments(storyId);

    // Comment form
    const commentForm = document.getElementById('commentForm');
    commentForm?.addEventListener('submit', async (e) => {
      e.preventDefault();
      const textarea = document.getElementById('commentText');
      const text = textarea.value.trim();
      if (!text) return;

      const submitBtn = commentForm.querySelector('button[type="submit"]');
      submitBtn.disabled = true;

      try {
        await apiPost('comments.php', { story_id: parseInt(storyId), text });
        textarea.value = '';
        showToast('💬 Komentar berhasil ditambahkan!');
        await loadComments(storyId);
      } catch (err) {
        showToast('❌ ' + err.message);
      } finally {
        submitBtn.disabled = false;
      }
    });

  } catch (err) {
    detailEl.innerHTML = `<div class="empty-state"><div class="icon">😕</div><h3>Cerita tidak ditemukan</h3><p>${err.message}</p><a href="index.html" class="btn btn-primary mt-md">Kembali ke Beranda</a></div>`;
  }
}

async function loadComments(storyId) {
  const list = document.getElementById('commentList');
  const countEl = document.getElementById('commentCount');
  if (!list) return;

  try {
    const data = await apiGet(`comments.php?story_id=${storyId}`);
    if (countEl) countEl.textContent = data.total;

    if (data.comments.length === 0) {
      list.innerHTML = `<div class="empty-state" style="padding:var(--space-xl) 0;"><div class="icon">💬</div><h3>Belum ada komentar</h3><p>Jadilah yang pertama memberikan dukungan!</p></div>`;
    } else {
      list.innerHTML = data.comments.map(c => `
        <div class="comment-item">
          <div class="comment-avatar">${c.anon_avatar}</div>
          <div class="comment-body">
            <div class="comment-author">${c.anon_name}</div>
            <div class="comment-time">${c.time_ago}</div>
            <p class="comment-text">${c.text}</p>
          </div>
        </div>
      `).join('');
    }
  } catch (e) {
    list.innerHTML = '<p style="color:var(--text-muted);">Gagal memuat komentar.</p>';
  }
}

// ---- Navigation ----
function navigateToStory(id) {
  window.location.href = `story.html?id=${id}`;
}

// ---- Toast ----
function showToast(message) {
  let toast = document.getElementById('toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'toast';
    toast.className = 'toast';
    document.body.appendChild(toast);
  }
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 3000);
}

// ---- Counter Animation ----
function animateCounter(el, target) {
  let current = 0;
  const step = Math.max(1, Math.ceil(target / 60));
  const interval = setInterval(() => {
    current += step;
    if (current >= target) { current = target; clearInterval(interval); }
    el.textContent = formatNumber(current);
  }, 30);
}

// ---- Header ----
function initHeader() {
  const header = document.querySelector('.header');
  if (header) {
    window.addEventListener('scroll', () => {
      header.classList.toggle('scrolled', window.scrollY > 10);
    });
  }

  const menuBtn = document.querySelector('.mobile-menu-btn');
  const mobileNav = document.querySelector('.mobile-nav');
  if (menuBtn && mobileNav) {
    menuBtn.addEventListener('click', () => {
      menuBtn.classList.toggle('open');
      mobileNav.classList.toggle('open');
      document.body.style.overflow = mobileNav.classList.contains('open') ? 'hidden' : '';
    });
    mobileNav.querySelectorAll('a').forEach(link => {
      link.addEventListener('click', () => {
        menuBtn.classList.remove('open');
        mobileNav.classList.remove('open');
        document.body.style.overflow = '';
      });
    });
  }
}

// ---- Init ----
document.addEventListener('DOMContentLoaded', () => {
  initHeader();
  const page = document.body.dataset.page;
  switch (page) {
    case 'home': initHomepage(); break;
    case 'post': initPostPage(); break;
    case 'story': initStoryDetail(); break;
  }
});
